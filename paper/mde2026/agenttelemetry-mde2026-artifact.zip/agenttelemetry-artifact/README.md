# AgentTelemetry MDE Intelligence 2026 — Replication Artifact

This artifact accompanies the paper *"A Metamodel for AI-Agent Telemetry:
Assessing Diagnostic Performance"* (5-page extended abstract, MDE Intelligence
2026 @ MODELS 2026, Málaga).

## Contents

| File | Purpose |
|---|---|
| `agenttelemetry.ecore` | Machine-readable Ecore metamodel: 9 typed `SpanKind` subclasses, derived `Delegation.sourceAgent`/`targetAgent` projections, `kind` discriminator EAnnotation |
| `agenttelemetry.ocl` | Six OCL well-formedness invariants (RootIsAgent, DelegationCarriesIdentity, NoCircularDelegation, CostMetricsRequired, GuardRailResultIsExplicit, KindMatchesSubtype) |
| `coverage_matrix.md` | Per-app DSM span-kind coverage (3/9 to 9/9 across the 7 benchmark apps) |
| `mast_mapping.md` | Mapping of the 14 fault types onto Cemri et al. (2025) MAST taxonomy |
| `requirements.lock` | Pinned Python 3.11+ environment for reproducibility |
| `run_benchmarks.py` | Benchmark runner — produces `results_full.tsv` |
| `compute_fpr.py` | False-positive-rate aggregator |
| `results_full.tsv` | Pre-computed per-run results (3,780 rows including header) |

## Reproduction

```bash
# Get the full repository (the runner depends on the rest of the AgentTelemetry SDK)
git clone https://github.com/Krishnachaitanyakc/AgentTelemetry.git
cd AgentTelemetry
git checkout <commit-tagged-for-mde2026>

# Pinned environment
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.lock && pip install -e .

# Re-run the benchmark (replaces benchmarks/results_full.tsv)
PYTHONPATH=src:. python benchmarks/run_benchmarks.py \
    --output benchmarks/results_full.tsv

# Compute the false-positive rate
PYTHONPATH=src:. python benchmarks/compute_fpr.py \
    benchmarks/results_full.tsv
```

Full matrix runs in approximately 3 minutes on a single CPU.

## Expected output

| Condition | FDR | FPR | Faults @ FDR=1.0 |
|---|---|---|---|
| `no_telemetry` | 0.000 | 0.000 | 0/14 |
| `vanilla_otel` | 0.429 | 0.000 | 6/14 |
| `otel_genai` | 0.429 | 0.000 | 6/14 |
| `openinference` | 0.429 | 0.000 | 6/14 |
| `metadata_only` (DSM) | 0.612 | 0.071 | 7/14 |
| `full_capture` (DSM) | 0.612 | 0.071 | 7/14 |
| `full_capture` on `custom_agent` only (upper bound) | **1.000** | **0.000** | **14/14** |

Numbers reproduce verbatim against `results_full.tsv`.

## OCL execution

To execute `agenttelemetry.ocl` against an exported trace:

1. Open Eclipse OCL or USE.
2. Load `agenttelemetry.ecore` as the metamodel.
3. Load any exported trace (the benchmark runner serializes traces as JSON;
   convert to an `agenttelemetry:Trace` instance with the
   `paper/supporting/trace_to_ecore.py` helper in the upstream repo).
4. Validate; all six invariants should hold for `custom_agent` traces and
   should diagnose the missing typed kinds for the other six benchmark apps.

## Citation

```
Krishna Chaitanya Balusu. 2026. A Metamodel for AI-Agent Telemetry:
Assessing Diagnostic Performance. In Proc. MDE Intelligence 2026
(MODELS Companion). ACM.
```
